#include "gtest/gtest.h"
#include "../lib/CaffGenerator.h"

