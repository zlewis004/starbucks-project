#include "../lib/CremeFrappuccino.h"
#include <string>

CremeFrappuccino::CremeFrappuccino()
{
    isHot = false;
}

std::string CremeFrappuccino::getName()
{
    return "Crème Frappuccino";
}
