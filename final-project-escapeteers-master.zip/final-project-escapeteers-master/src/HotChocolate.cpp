#include "../lib/HotChocolate.h"
#include <string>

std::string HotChocolate::getName()
{
    return "Hot Chocolate";
}
